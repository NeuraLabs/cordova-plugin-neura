//
//  NeuraRequest.h
//  NeuraSDK
//
//  Created by Neura on 30/11/2016.
//  Copyright © 2016 Neura. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface NeuraRequest : NSObject

-(BOOL)isValid;

@end
