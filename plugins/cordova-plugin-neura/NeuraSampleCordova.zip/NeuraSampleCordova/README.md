# NeuraSampleApp

## Usage

git clone https://github.com/jeweller1980stepanets/NeuraSampleApp

cd NeuraSampleApp/

cordova platform add android

cordova run android

## IOS

> You must register app in Firebase and download GoogleService-Info.plist and add it to root catalog

cordova platform add ios

cordova run ios

Also you must register application on https://dev.theneura.com/console/app/new 
After that you can use webHookId for subscribe to events.

